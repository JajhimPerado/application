package com.example.lakbaygabayquiz;

public class QuestionAnswer {

    public static String question[] ={
            "What’s the minimum safe following distance in the city on dry roads?",
            "When you’re stopped in traffic at a red light on the way to work, where should you be checking regularly?",
            "You should check your rearview mirror",
            "If another driver shows that they’re road raging toward you, what should you do?",
            "What is the average distance traveled by a vehicle moving at a speed of 72 KM per hr in 1 second?",
            "To move a vehicle from stationary position, the sequence of operation is:",
            "The safe way to stop the vehicle is:",
    };

    public static String choices[][] = {
            {"2 seconds behind the other vehicle", "20 metres behind the other vehicle", "3 car lengths behind the other vehicle", "2 car lengths behind the other vehicle"},
            {"Traffic approaching from behind", "Dashboard warning lights", "Your hair", "Traffic to the left and right"},
            {"Every 5 to 8 seconds", "To check your make-up or hair", "When you think there may be a problem behind you", "After you apply the brake"},
            {"Drive away from them quickly", "Stare at them", "Ignore them", "Drive to a quiet, remote location"},
            {"10 m", "20 m", "16.66 m", "33.2"},
            {"Mirror start signal move", "Start gear mirror signal move", "Start mirror signal gear move", "None of the Above"},
            {"Press clutch and then brake","Press brake and then clutch","Press brake and clutch at a time","None of the Above"},
    };

    public static String correctAnswer[] = {
            "2 seconds behind the other vehicle",
            "Traffic approaching from behind",
            "Every 5 to 8 seconds",
            "Ignore them",
            "20 m",
            "Start gear mirror signal move",
            "Press brake and clutch at a time"
    };
}
